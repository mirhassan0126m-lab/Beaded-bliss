<div class="product">
    <h2><?php echo $product['name']; ?></h2>
    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
    <p><?php echo $product['description']; ?></p>
    <p>Price: <?php echo $product['price']; ?></p>
    <button>Add to Cart</button>
</div>
