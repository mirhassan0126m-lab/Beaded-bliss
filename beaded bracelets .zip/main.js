<!-- Preview -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Website</title>
  <style>
    /* paste style.css content here */
  </style>
</head>
<body>
  <!-- paste index.html content here -->
  <script>
    /* paste main.js content here */
  </script>
</body>
</html>
