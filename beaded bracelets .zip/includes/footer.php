<footer>
    <p>&copy; 2023 Handmade Bracelets by Beadify</p>
</footer>
