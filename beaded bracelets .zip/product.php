<?php
// Get product
$id = $_GET['id'];
$product = get_product($id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - Handmade Bracelets by Beadify</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    <!-- End Header -->

    <!-- Main Content -->
    <main>
        <section class="product">
            <h1><?php echo $product['name']; ?></h1>
            <img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
            <p>Rs. <?php echo $product['price']; ?></p>
            <p><?php echo $product['description']; ?></p>
            <form action="cart.php" method="post">
                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                <input type="number" name="quantity" value="1">
                <input type="submit" value="Add to Cart">
            </form>
        </section>
    </main>
    <!-- End Main Content -->

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    <!-- End Footer -->

    <script src="js/script.js"></script>
</body>
</html>
