<?php
$lang = array(
    'home' => 'Home',
    'products' => 'Products',
    'about' => 'About',
    'contact' => 'Contact',
    // Add more language strings here
);
?>
